﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Data;

namespace WebApplication1.Controllers
{
    public class CategoriesController : Controller
    {
        ApplicationDbContext context = new ApplicationDbContext();
        public ViewResult Index()
        {
            var categories = context.Categories.ToList();
            return View(categories);
        }
        public ViewResult Details(int id)
        {
            var category = context.Categories.Find(id);
            return View(category);
        }
    }
}
